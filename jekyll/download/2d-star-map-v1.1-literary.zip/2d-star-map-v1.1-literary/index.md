## Index of well-known stars

| Star name                 | X, Y     | Sector                 |
|---------------------------|----------|------------------------|
| 268 G. Cet                | 425, 275 | Mu-XII [12:12]         |
| 33 G. Lib                 | 51, 565  | Beta-XXIII [2:23]      |
| 82 G. Eri                 | 798, 44  | Psi-II [23:2]          |
| 96 G. Psc                 | 380, 275 | Lambda-XII [11:12]     |
| Aldebaran                 | 563, 144 | Pi-VI [16:6]           |
| Alderamin                 | 379, 559 | Lambda-XXIII [11:23]   |
| Algol                     | 485, 84  | Xi-IV [14:4]           |
| Alhena                    | 615, 96  | Sigma-IV [18:4]        |
| Alioth                    | 473, 480 | Xi-XX [14:20]          |
| Alkaid                    | 450, 468 | Nu-XIX [13:19]         |
| Alnair                    | 120, 217 | Delta-IX [4:9]         |
| Alphekka                  | 351, 439 | Kappa-XVIII [10:18]    |
| Alpheratz                 | 340, 85  | Kappa-IV [10:4]        |
| Altair                    | 348, 317 | Kappa-XIII [10:13]     |
| Ankaa                     | 105, 149 | Gamma-VI [3:6]         |
| Arcturus                  | 424, 382 | Mu-XVI [12:16]         |
| Barnard's Star            | 393, 318 | Lambda-XIII [11:13]    |
| Capella                   | 521, 25  | Omicron-II [15:2]      |
| Caph                      | 411, 11  | Mu-I [12:1]            |
| Castor                    | 632, 9   | Sigma-I [18:1]         |
| Denebola                  | 511, 368 | Omicron-XV [15:15]     |
| Diphda                    | 166, 139 | Epsilon-VI [5:6]       |
| Fomalhaut                 | 109, 21  | Delta-I [4:1]          |
| Groombridge 1618          | 458, 326 | Nu-XIV [13:14]         |
| Groombridge 1830          | 478, 358 | Xi-XV [14:15]          |
| Hamal                     | 427, 127 | Mu-VI [12:6]           |
| Kapteyn's Star            | 784, 32  | Chi-II [22:2]          |
| Kruger 60                 | 399, 310 | Mu-XIII [12:13]        |
| Lacaille 8760             | 89, 597  | Gamma-XXIV [3:24]      |
| Lacaille 9352             | 378, 300 | Lambda-XIII [11:13]    |
| Lalande 21185             | 439, 321 | Nu-XIII [13:13]        |
| Luyten's Star             | 471, 308 | Xi-XIII [14:13]        |
| Merak                     | 519, 501 | Omicron-XXI [15:21]    |
| Mizar                     | 458, 474 | Nu-XIX [13:19]         |
| Phad                      | 507, 485 | Omicron-XX [15:20]     |
| Pollux                    | 528, 312 | Omicron-XIII [15:13]   |
| Procyon                   | 467, 310 | Nu-XIII [13:13]        |
| Proxima Centauri          | 411, 313 | Mu-XIII [12:13]        |
| Rasalhague                | 284, 389 | Theta-XVI [8:16]       |
| Regulus                   | 640, 451 | Sigma-XIX [18:19]      |
| Rigel Kentaurus A         | 411, 314 | Mu-XIII [12:13]        |
| Rigel Kentaurus B         | 411, 314 | Mu-XIII [12:13]        |
| Sirius                    | 447, 306 | Nu-XIII [13:13]        |
| Sol                       | 414, 312 | Mu-XIII [12:13]        |
| Unukalhai                 | 138, 472 | Delta-XIX [4:19]       |
| Van Maanen's Star         | 393, 290 | Lambda-XII [11:12]     |
| Vega                      | 356, 339 | Kappa-XIV [10:14]      |
| Vindemiatrix              | 756, 483 | Chi-XX [22:20]         |
| p Eridani                 | 14, 39   | Alpha-II [1:2]         |
