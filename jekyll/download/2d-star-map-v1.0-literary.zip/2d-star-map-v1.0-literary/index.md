## Index of well-known stars

| 268 G. Cet | 425, 274 | Mu-XI [12:11] |
| 33 G. Lib | 51, 564 | Beta-XXIII [2:23] |
| 82 G. Eri | 798, 43 | Psi-II [23:2] |
| 96 G. Psc | 380, 274 | Lambda-XI [11:11] |
| Aldebaran | 563, 143 | Pi-VI [16:6] |
| Alderamin | 379, 558 | Lambda-XXIII [11:23] |
| Algol | 485, 83 | Xi-IV [14:4] |
| Alhena | 615, 95 | Sigma-IV [18:4] |
| Alioth | 473, 479 | Xi-XX [14:20] |
| Alkaid | 450, 467 | Nu-XIX [13:19] |
| Alnair | 120, 216 | Delta-IX [4:9] |
| Alphekka | 351, 438 | Kappa-XVIII [10:18] |
| Alpheratz | 340, 84 | Kappa-IV [10:4] |
| Altair | 348, 316 | Kappa-XIII [10:13] |
| Ankaa | 105, 148 | Gamma-VI [3:6] |
| Arcturus | 424, 381 | Mu-XVI [12:16] |
| Barnard's Star | 393, 317 | Lambda-XIII [11:13] |
| Capella | 521, 24 | Omicron-I [15:1] |
| Caph | 411, 10 | Mu-I [12:1] |
| Castor | 632, 8 | Sigma-I [18:1] |
| Denebola | 511, 367 | Omicron-XV [15:15] |
| Diphda | 166, 138 | Epsilon-VI [5:6] |
| Fomalhaut | 109, 20 | Delta-I [4:1] |
| Groombridge 1618 | 458, 325 | Nu-XIV [13:14] |
| Groombridge 1830 | 478, 357 | Xi-XV [14:15] |
| Hamal | 427, 126 | Mu-VI [12:6] |
| Kapteyn's Star | 784, 31 | Chi-II [22:2] |
| Kruger 60 | 399, 309 | Mu-XIII [12:13] |
| Lacaille 8760 | 89, 596 | Gamma-XXIV [3:24] |
| Lacaille 9352 | 378, 299 | Lambda-XII [11:12] |
| Lalande 21185 | 439, 320 | Nu-XIII [13:13] |
| Luyten's Star | 471, 307 | Xi-XIII [14:13] |
| Merak | 519, 500 | Omicron-XXI [15:21] |
| Mizar | 458, 473 | Nu-XIX [13:19] |
| Phad | 507, 484 | Omicron-XX [15:20] |
| Pollux | 528, 311 | Omicron-XIII [15:13] |
| Procyon | 467, 309 | Nu-XIII [13:13] |
| Proxima Centauri | 411, 312 | Mu-XIII [12:13] |
| Rasalhague | 284, 388 | Theta-XVI [8:16] |
| Regulus | 640, 450 | Sigma-XIX [18:19] |
| Rigel Kentaurus A | 411, 313 | Mu-XIII [12:13] |
| Rigel Kentaurus B | 411, 313 | Mu-XIII [12:13] |
| Sirius | 447, 305 | Nu-XIII [13:13] |
| Sol | 414, 311 | Mu-XIII [12:13] |
| Unukalhai | 138, 471 | Delta-XIX [4:19] |
| Van Maanen's Star | 393, 289 | Lambda-XII [11:12] |
| Vega | 356, 338 | Kappa-XIV [10:14] |
| Vindemiatrix | 756, 482 | Chi-XX [22:20] |
| p Eridani | 14, 38 | Alpha-II [1:2] |
